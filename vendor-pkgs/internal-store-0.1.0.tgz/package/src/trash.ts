// ⚠ 使用前必读 README.md + CONTEXT.md。app 不直接 import——经 createStore。
//
// trash（深模块）—— 回收站生命周期：restore / purge / emptyTrash。单一职责 = .trash 的恢复与彻底删：
//   restore：本地先恢复（撞名自动 (2)）→ 云端按同名恢复；采纳恢复出的云 item etag（move→新 etag）。
//   purge：永久删（不可恢复）→ 强制 danger confirm。
//   emptyTrash：批量彻底删，本地/云端一处清，逐项独立 try、失败汇总不静默；**强退=cancel，绝不自动续**。
import { reportStoreError } from "./error-handling.ts";   // 全接但分级：静默 swallow 也 funnel（不改控制流）
import type { CloudItem, CloudSync, LocalCache } from "./types.ts";
import type { LocalHead } from "./local-head.ts";

import type { Busy } from "./types.ts";
const passBusy: Busy = (_l, fn) => fn();

export interface TrashCfg {
  cloud: Pick<CloudSync, "restore" | "purge" | "listTrash" | "listBackup">;
  local?: Pick<LocalCache, "restore" | "purgeTrash" | "listTrash" | "listBackup">;
  head: Pick<LocalHead, "markSeen">;
  busy?: Busy;
}
/** restore（从回收站恢复）的选项。 */
export interface RestoreOpts {
  /** 走云端腿恢复。 */
  fromCloud?: boolean;
  /** 云端 trash item id（云端腿）。 */
  cloudItemId?: string | null;
  /** 恢复的目标名。 */
  targetName?: string;
  /** 本地 trashKey（本地腿）。 */
  trashKey?: string | null;
  /** trash 里的字节是加密容器 → 恢复落 encFileName。 */
  encrypted?: boolean;
  /** busy 遮罩注入。 */
  busy?: Busy }
/** purge（永久删，不可恢复）的选项。 */
export interface PurgeOpts {
  /** 本地 trashKey（本地腿）。 */
  trashKey?: string | null;
  /** 云端 trash item id（云端腿）。 */
  cloudItemId?: string | null;
  /** danger confirm 回调。 */
  confirm?: (ctx: { title: string; body: string; danger?: boolean }) => boolean | Promise<boolean>;
  /** busy 遮罩注入。 */
  busy?: Busy }
/** emptyTrash（批量彻底删）的选项。 */
export interface EmptyTrashOpts {
  /** 在线判定注入。 */
  isOnline?: () => boolean;
  /** busy 遮罩注入。 */
  busy?: Busy;
  /** 并发数。 */
  concurrency?: number;
  /** 清哪一端。 */
  scope?: "local" | "cloud" | "both" }
/** restore / purge / emptyTrash 的终态。 */
export interface TrashResult {
  /** 终态串。 */
  status: string;
  /** 涉及的文件名。 */
  name?: string | null;
  /** 本地腿标志。 */
  local?: boolean;
  /** 云端腿标志。 */
  cloud?: boolean;
  /** 彻底删的条数。 */
  purged?: number;
  /** 失败汇总（逐项独立 try、不静默）。 */
  failed?: unknown[] }

export function createTrash(cfg: TrashCfg) {
  const { cloud, local, head, busy: _busy = passBusy } = cfg;

  async function restore(opts: RestoreOpts = {}): Promise<TrashResult> {
    const { fromCloud, cloudItemId, targetName, trashKey, encrypted, busy = _busy } = opts;
    return busy("恢复中…", async () => {
      let name: string | null = targetName || null, restoredLocal = false, restoredCloud = false;
      // both 行策略：本地先恢复到**原名**；云端腿随后 cloud.restore 撞名自动 (2)（复用其重试）→ 两份都在、不覆盖。
      if (trashKey && local) { const n = await local.restore(trashKey); if (n) { name = n; restoredLocal = true; } }
      if (fromCloud && cloudItemId != null) {
        const ritem = await cloud.restore(cloudItemId, (name || targetName)!, { encrypted }) as { eTag?: string | null };
        restoredCloud = true;
        // 采纳恢复出的云 item etag（restore 是 move → 新 etag）→ 之后 push 有 base，不对自己的文件弹假撞名。
        const rname = name || targetName;
        if (rname && ritem && ritem.eTag) head.markSeen(rname, ritem.eTag);
      }
      if (!restoredLocal && !restoredCloud) return { status: "noop" };
      return { status: "restored", name, local: restoredLocal, cloud: restoredCloud };
    });
  }

  async function purge(opts: PurgeOpts = {}): Promise<TrashResult> {
    const { trashKey, cloudItemId, confirm, busy = _busy } = opts;
    if (confirm && !(await confirm({ title: "彻底删除", body: "不可恢复", danger: true }))) return { status: "cancelled" };
    return busy("彻底删除…", async () => {
      if (trashKey && local && local.purgeTrash) await local.purgeTrash(trashKey);
      if (cloudItemId != null) await cloud.purge(cloudItemId);
      return { status: "purged" };
    });
  }

  // 批量彻底删：scope 选端（"local"/"cloud"/"both"）。强退=cancel（绝不自动续：下次 trash 可能已有新 item）。
  async function emptyTrash(opts: EmptyTrashOpts = {}): Promise<TrashResult> {
    const { isOnline, busy = _busy, concurrency = 5, scope = "both" } = opts;
    return busy("清空回收站…", async () => {
      let purged = 0; const failed: { name?: string; where: string; error: string }[] = [];
      const errMsg = (e: unknown) => String((e as { message?: unknown })?.message || e);
      if (scope !== "cloud" && local && local.listTrash && local.purgeTrash) {
        for (const t of await local.listTrash()) {
          try { await local.purgeTrash(t.trashKey); purged++; }
          catch (e) { reportStoreError(e, "warning"); failed.push({ name: t.name, where: "local", error: errMsg(e) }); }
        }
      }
      if (scope !== "local" && (!isOnline || isOnline())) {
        let items: CloudItem[] | null = null;
        try { items = await cloud.listTrash(); } catch (e) { reportStoreError(e, "warning"); failed.push({ where: "cloud-list", error: errMsg(e) }); }
        items = items || [];
        for (let i = 0; i < items.length; i += concurrency) {   // bounded 并发，快约 N×
          await Promise.all(items.slice(i, i + concurrency).map(async (it) => {
            try { await cloud.purge(it.id, it.eTag); purged++; }
            catch (e) { reportStoreError(e, "warning"); failed.push({ name: it.name, where: "cloud", error: errMsg(e) }); }
          }));
        }
      }
      return { status: "emptied", purged, failed };
    });
  }

  // 清空**备份箱**（.backup / 本地 backup 分区）：weakOverride/keepMine 的 loser 字节 stash 处。
  //   与 emptyTrash 同纪律：scope 选端、逐项独立 try、失败汇总不静默、强退=cancel。备份用 listBackup + 通用 purge/purgeTrash。
  async function emptyBackup(opts: EmptyTrashOpts = {}): Promise<TrashResult> {
    const { isOnline, busy = _busy, concurrency = 5, scope = "both" } = opts;
    return busy("清空备份箱…", async () => {
      let purged = 0; const failed: { name?: string; where: string; error: string }[] = [];
      const errMsg = (e: unknown) => String((e as { message?: unknown })?.message || e);
      if (scope !== "cloud" && local && local.listBackup && local.purgeTrash) {
        for (const b of await local.listBackup()) {
          try { await local.purgeTrash(b.trashKey); purged++; }   // purgeTrash 认 `backup/` 前缀 → 走 backup 分区
          catch (e) { reportStoreError(e, "warning"); failed.push({ name: b.name, where: "local", error: errMsg(e) }); }
        }
      }
      if (scope !== "local" && (!isOnline || isOnline())) {
        let items: CloudItem[] | null = null;
        try { items = await cloud.listBackup(); } catch (e) { reportStoreError(e, "warning"); failed.push({ where: "cloud-list", error: errMsg(e) }); }
        items = items || [];
        for (let i = 0; i < items.length; i += concurrency) {
          await Promise.all(items.slice(i, i + concurrency).map(async (it) => {
            try { await cloud.purge(it.id, it.eTag); purged++; }
            catch (e) { reportStoreError(e, "warning"); failed.push({ name: it.name, where: "cloud", error: errMsg(e) }); }
          }));
        }
      }
      return { status: "emptied", purged, failed };
    });
  }

  return { restore, purge, emptyTrash, emptyBackup };
}
